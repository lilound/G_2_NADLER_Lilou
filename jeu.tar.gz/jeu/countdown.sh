#!/bin/bash
duration=$1
end_time=$(( $(date +%s) + duration*60 ))

while [ $(date +%s) -lt $end_time ]; do
  remaining=$(( end_time - $(date +%s) ))
  minutes=$(( remaining / 60 ))
  seconds=$(( remaining % 60 ))
  echo " Il reste $minutes minutes et $seconds secondes avant que la fatigue ne vous rattrape..."
  sleep 60
done

echo " Vous vous endormez... La soirée est terminée."
touch .countdown_expired