#!/bin/bash
rm -f .can_go .start_time .final_time .module_OK .error .log
rm -f .encoded* .serial recette.txt indice.txt mission.txt requete.txt adresse.txt infos.txt
rm -rf porte after cle_* burger orange pizza
rm -f *.gif mini_games_list
echo "Environnement réinitialisé. La soirée peut recommencer."