#!/bin/bash
# Surveille le nombre d'erreurs pendant la soirée

max_errors=$1

while true; do
  if [[ -f .error ]]; then
    errors=$(cat .error)
    if [[ $errors -ge $max_errors ]]; then
      echo "Trop d’erreurs... votre cerveau surchauffe."
      echo "Vous vous endormez sur le canapé, la soirée est terminée."
      touch .game_over
      exit 1
    fi
  fi
  sleep 5
done