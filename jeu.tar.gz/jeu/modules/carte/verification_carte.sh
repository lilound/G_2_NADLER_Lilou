#!/bin/bash

cd poches_carte || { echo "Dossier poches_carte introuvable."; exit 1; }

# Initialiser le fichier d’erreurs s’il n’existe pas
touch erreurs.txt

read -p "Où se trouve la carte étudiante ? (chemin relatif à poches_carte) : " user_path

# Vérifie si le fichier existe et contient le bon contenu
if [ -f "$user_path" ] && grep -q "ETU123" "$user_path"; then
  echo " Bravo ! Tu as retrouvé ta carte étudiante."
else
  echo " Mauvais chemin ou contenu incorrect. Réessaie !"
  echo "1" >> erreurs.txt
fi

# Vérifie le nombre d’erreurs
error_count=$(grep -c "1" erreurs.txt 2>/dev/null)
error_count=${error_count:-0}

if [ "$error_count" -ge 3 ]; then
  echo " Trop d’erreurs... tu as perdu ce niveau."
  bash ../remise_zero.sh
  exit 1
fi