#!/bin/bash

# Remise à zéro
source remise_zero.sh

# Créer le dossier principal
mkdir -p poches_carte
cd poches_carte || exit 1

# Générer une arborescence profonde
for i in $(seq 1 3); do
  mkdir -p "niveau_${i}"
  cd "niveau_${i}"
  for j in $(seq 1 3); do
    mkdir -p "sous_${j}"
    cd "sous_${j}"
    for k in $(seq 1 2); do
      mkdir -p "fond_${k}"
      for f in $(seq 1 3); do
        touch "fond_${k}/fichier_${f}.txt"
      done
    done
    cd ..
  done
  cd ../..
done

# Cacher la carte dans un dossier profond aléatoire
target_dir=$(find . -type d -name "fond_*" | shuf -n 1)
echo "ETU123" > "$target_dir/carte_etudiante"

echo "Ta carte est bien planquée... À toi de la retrouver ! Indice : elle est dans un fichier nommé carte_etudiante"