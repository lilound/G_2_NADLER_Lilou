#!/bin/bash
rm -rf poches_carte
echo "Module Carte étudiante réinitialisé."