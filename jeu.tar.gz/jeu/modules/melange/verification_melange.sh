#!/bin/bash

# Vérifier que la recette existe
if [ ! -f recette.txt ]; then
  echo "Pas de recette trouvée. Lance d'abord start_melange.sh."
  exit 1
fi

# Lire le cocktail cible
target=$(grep "Cocktail recherché" recette.txt | awk -F ": " '{print $2}')

# Vérifier que le processus est lancé
pid_line=$(grep "$target" pids.txt)
if [ -z "$pid_line" ]; then
  echo "Le processus du cocktail $target n'est pas en cours."
  exit 1
fi

pid=$(echo "$pid_line" | cut -d ":" -f2)

# Vérifier l'utilisation CPU avec ps
cpu=$(ps -p "$pid" -o %cpu= | awk '{print int($1)}')

if [ "$cpu" -ge 5 ] && [ "$cpu" -le 30 ]; then
  echo "Bravo ! Le cocktail $target est correct (CPU $cpu%)."
else
  echo "Dommage... Le cocktail $target n'a pas le bon profil CPU (CPU $cpu%)."
fi