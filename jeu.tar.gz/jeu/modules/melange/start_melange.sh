#!/bin/bash

# Remise à zéro
source remise_zero.sh
rm -f *.sh pids.txt recette.txt
mkdir -p cocktails
> pids.txt

# Définir les cocktails et leurs ingrédients
declare -A cocktails
cocktails["mojito"]="rhum menthe citron sucre eau_gazeuse"
cocktails["pina_colada"]="rhum ananas coco"
cocktails["caipirinha"]="cachaca citron sucre"
cocktails["tequila_sunrise"]="tequila orange grenadine"

# Créer les fichiers d’ingrédients et les scripts de simulation
for drink in "${!cocktails[@]}"; do
  echo "${cocktails[$drink]}" > "cocktails/${drink}.txt"

  case "$drink" in
    "mojito")
      cat > "${drink}.sh" <<'EOF'
#!/bin/bash
while true; do echo 'Préparation mojito' > /dev/null; sleep 1; done
EOF
      ;;
    "pina_colada")
      cat > "${drink}.sh" <<'EOF'
#!/bin/bash
while true; do dd if=/dev/zero of=/dev/null bs=1M count=50 2>/dev/null; sleep 1; done
EOF
      ;;
    "caipirinha")
      cat > "${drink}.sh" <<'EOF'
#!/bin/bash
while true; do yes 'caipirinha' > /dev/null; sleep 2; done
EOF
      ;;
    "tequila_sunrise")
      cat > "${drink}.sh" <<'EOF'
#!/bin/bash
while true; do seq 1 5000 > /dev/null; sleep 3; done
EOF
      ;;
  esac

  chmod +x "${drink}.sh"
  ./"${drink}.sh" &   # Lancer le processus
  echo "$drink:$!:${drink}.sh" >> pids.txt
done

# Cocktail cible fixé (pas d’aléatoire)
target="mojito"

# Générer la recette
cat > recette.txt <<EOF
Tu ne te souviens plus de ton cocktail...
Heureusement, tu avais noté quelques indices :

Cocktail recherché : $target
Ingrédients : ${cocktails[$target]}
Critère : CPU entre 5% et 30%
EOF

echo "Les cocktails sont en préparation... À toi de jouer !"