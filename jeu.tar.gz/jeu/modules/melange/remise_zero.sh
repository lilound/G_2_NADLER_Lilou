#!/bin/bash

# Arrêter tous les processus cocktails encore actifs
if [ -f pids.txt ]; then
  while IFS=: read -r drink pid script; do
    if ps -p "$pid" > /dev/null 2>&1; then
      kill -9 "$pid" 2>/dev/null
    fi
  done < pids.txt
fi

# Nettoyage des fichiers
rm -f pids.txt recette.txt
rm -f mojito.sh pina_colada.sh caipirinha.sh tequila_sunrise.sh
rm -rf cocktails

# Message de confirmation
echo "Remise à zéro effectuée : tous les cocktails ont été arrêtés et les fichiers nettoyés."