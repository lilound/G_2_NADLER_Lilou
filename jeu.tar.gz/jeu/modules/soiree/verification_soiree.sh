#!/bin/bash

if [ ! -f .erreurs_after ]; then
  echo 0 > .erreurs_after
fi

if [ ! -f infos.txt ]; then
  echo "Fichier infos.txt introuvable."
  exit 1
fi

reponse=$(cat lieu.txt | xargs)
attendue=$(cat .bonne_reponse | xargs)
erreurs=$(cat .erreurs_after)

if [ "$erreurs" -ge 3 ]; then
  echo "Tu as dépassé les 3 tentatives. La soirée est finie."
  exit 1
fi

if [ "$reponse" == "$attendue" ]; then
  echo "Bravo ! Tu as trouvé l'adresse complète."
  if [ "$erreurs" -gt 0 ]; then
    echo "Tu as réussi après $erreurs tentative(s)."
  fi
else
  erreurs=$((erreurs + 1))
  echo "$erreurs" > .erreurs_after
  echo "Erreur $erreurs : réponse incorrecte → \"$reponse\"" >> erreurs_after.txt

  if [ "$erreurs" -ge 3 ]; then
    echo "Dommage... Tu as atteint la limite de 3 erreurs. Relance le module pour réessayer."
  else
    echo "Dommage ! Réessaie... ($erreurs/3)"
  fi
fi