#!/bin/bash

source remise_zero.sh

# Générer le fichier adresse.txt
cat > adresse.txt <<EOF
Toï Toï, 23h45, salle du haut
K-Fêt INSA, 20h30, salle du bas
Bâtiment TC, 1h00, couloir central
Humanités, minuit, salle 204
RI, 2h15, salle du fond
EOF

# Tirer trois lignes différentes
lignes=($(shuf adresse.txt | head -n 3))

lieu=$(echo "${lignes[0]}" | cut -d',' -f1 | xargs)
heure=$(echo "${lignes[1]}" | cut -d',' -f2 | xargs)
salle=$(echo "${lignes[2]}" | cut -d',' -f3 | xargs)

# Composer la réponse attendue
echo "$lieu, $heure, $salle" > .bonne_reponse

# Générer l’indice
echo "Compose l’adresse de l’after avec : le lieu de '${lignes[0]}', l’heure de '${lignes[1]}', la salle de '${lignes[2]}'" > indice.txt

echo "Le module est lancé. Lis adresse.txt et indice.txt. Crée un dossier nommé after, copies y adresse.txt sous le nom info.txt puis modifie infos.txt avec vi."