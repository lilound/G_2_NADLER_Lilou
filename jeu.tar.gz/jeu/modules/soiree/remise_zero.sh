#!/bin/bash

rm -f adresse.txt lieu.txt infos.txt indice.txt
rm -f .ligne_cible .bonne_reponse .erreurs_after erreurs_after.txt
rm -rf soiree