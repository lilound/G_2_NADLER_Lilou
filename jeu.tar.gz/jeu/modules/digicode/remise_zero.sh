#!/bin/bash

# Nettoyage Digicode 1
rm -rf porte
rm -f code.txt .ligne_cible .bonne_adresse
rm -f info.txt .erreurs_digicode1 erreurs_digicode1.txt

# Nettoyage Digicode 2
rm -f mission.txt resultat.txt fichier_secret.txt index.html testfile.txt
rm -f .bonne_reponse .erreurs_digicode2 erreurs_digicode2.txt

echo "Modules Digicode 1 et Digicode 2 réinitialisés."