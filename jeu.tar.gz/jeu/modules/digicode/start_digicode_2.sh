#!/bin/bash

source remise_zero.sh

# Liste des missions en français (sans commande)
missions=(
"Tester la connexion avec un site distant"
"Télécharger un fichier depuis Internet"
"Analyser le type d’un fichier"
"Mesurer la taille d’un fichier"
"Lister les interfaces réseau disponibles"
)

# Commandes associées (même ordre)
commandes=(
"ping -c 3 example.com > resultat.txt"
"wget https://example.com/fichier_secret.txt"
"file fichier_secret.txt > resultat.txt"
"du -h fichier_secret.txt > resultat.txt"
"ip link > resultat.txt"
)

# Choisir un index aléatoire
index=$(shuf -i 0-4 -n 1)
mission="${missions[$index]}"
commande="${commandes[$index]}"

# Créer le fichier mission.txt (consigne uniquement)
echo "Mission : $mission" > mission.txt

# Créer le fichier si nécessaire
if [[ "$commande" == *"fichier_secret.txt"* ]]; then
  echo "Contenu confidentiel : Bravo" > fichier_secret.txt
fi

# Générer la bonne réponse
if [[ "$commande" == *"ping"* ]]; then
  echo "PING" > .bonne_reponse
elif [[ "$commande" == *"ip link"* ]]; then
  ip link | wc -l | xargs > .bonne_reponse
elif [[ "$commande" == *"du -h"* ]]; then
  du -h fichier_secret.txt | cut -f1 | xargs > .bonne_reponse
elif [[ "$commande" == *"file"* ]]; then
  file fichier_secret.txt | cut -d ":" -f2 | xargs > .bonne_reponse
elif [[ "$commande" == *"wget"* ]]; then
  echo "Bravo" > .bonne_reponse
fi

echo "Le module est lancé. Lis mission.txt, réalise l’action demandée, et place la commande effectuée dans resultat.txt après l'avoir créé."