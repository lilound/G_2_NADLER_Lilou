#!/bin/bash

# Initialiser le compteur d’erreurs si absent
if [ ! -f .erreurs_digicode1 ]; then
  echo 0 > .erreurs_digicode1
fi

# Vérifier la présence de la réponse attendue
if [ ! -f .bonne_reponse ]; then
  echo "Le module n’a pas été lancé correctement. Fichier .bonne_reponse manquant."
  exit 1
fi

# Lire la réponse attendue
attendue=$(cat .bonne_reponse | xargs)
erreurs=$(cat .erreurs_digicode1)

# Trop d’erreurs ?
if [ "$erreurs" -ge 3 ]; then
  echo "Tu as dépassé les 3 tentatives. La porte reste verrouillée. Relance le module pour réessayer."
  exit 1
fi

# Demander le code
echo -n "Entrez le digicode : "
read reponse

# Vérification
if [ "$reponse" == "$attendue" ]; then
  echo "Bravo ! Le digicode est correct. Tu peux entrer."
  if [ "$erreurs" -gt 0 ]; then
    echo "Tu as réussi après $erreurs tentative(s)."
  fi
else
  erreurs=$((erreurs + 1))
  echo "$erreurs" > .erreurs_digicode1
  echo "Erreur $erreurs : \"$reponse\"" >> erreurs_digicode1.txt

  if [ "$erreurs" -ge 3 ]; then
    echo "Dommage... Tu as atteint la limite de 3 erreurs. La porte reste fermée. Relance le module pour réessayer."
  else
    echo "Mauvais code. Réessaie. ($erreurs/3)"
    echo
    echo "Rappel : explore le dossier porte, lis ordre.txt, filtre les vrais fragments, et assemble le digicode."
    echo "Un fichier est un indice sur le code s’il contient le mot 'code' et si la seule chose présente après les ':' est un chiffre."
    echo "Le fichier ordre.txt indique l’ordre de placement des chiffres."
  fi
fi