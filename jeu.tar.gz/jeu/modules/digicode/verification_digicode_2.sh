#!/bin/bash

if [ ! -f .erreurs_digicode2 ]; then
  echo 0 > .erreurs_digicode2
fi

if [ ! -f resultat.txt ]; then
  echo "Fichier resultat.txt introuvable. Tu dois le créer et y écrire la commande utilisée."
  exit 1
fi

reponse=$(cat resultat.txt | xargs)
attendue=$(cat .bonne_reponse | xargs)
erreurs=$(cat .erreurs_digicode2)

if [ "$erreurs" -ge 3 ]; then
  echo "Tu as dépassé les 3 tentatives. Le sas réseau reste verrouillé. Relance le module pour réessayer."
  exit 1
fi

if [ "$reponse" == "$attendue" ]; then
  echo "Bravo ! Tu as franchi le sas réseau."
  if [ "$erreurs" -gt 0 ]; then
    echo "Tu as réussi après $erreurs tentative(s)."
  fi
else
  erreurs=$((erreurs + 1))
  echo "$erreurs" > .erreurs_digicode2
  echo "Erreur $erreurs : \"$reponse\"" >> erreurs_digicode2.txt

  if [ "$erreurs" -ge 3 ]; then
    echo "Dommage... Tu as atteint la limite de 3 erreurs. Le sas reste fermé. Relance le module pour réessayer."
  else
    echo "Réponse incorrecte. Réessaie. ($erreurs/3)"
    echo
    echo "Rappel : lis mission.txt, réalise l’action demandée, et place la commande effectuée dans resultat.txt après l’avoir créé."
  fi
fi