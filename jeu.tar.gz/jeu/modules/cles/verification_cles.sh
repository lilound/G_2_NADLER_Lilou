#!/bin/bash

if [ ! -f .bonne_reponse ]; then
  echo "Le module n’a pas été lancé correctement."
  exit 1
fi

attendu=$(cat .bonne_reponse | xargs)
present=$(echo "$PATH" | tr ':' '\n' | grep -Fx "$attendu")

if [ -n "$present" ]; then
  echo "Bravo ! La bonne clé est accessible via PATH."
else
  echo "Dommage ! Le bon dossier n’est pas dans PATH."
fi