#!/bin/bash

source remise_zero.sh

# Générer une liste de noms de dossiers uniques
noms=()
while [ "${#noms[@]}" -lt 100 ]; do
  nom="dossier_$((RANDOM % 10000))"
  if [[ ! " ${noms[@]} " =~ " $nom " ]]; then
    noms+=("$nom")
  fi
done

# Créer 30 chemins aléatoires avec 2 à 4 niveaux
for i in $(seq 1 30); do
  profondeur=$((RANDOM % 3 + 2))
  chemin=""

  for j in $(seq 1 $profondeur); do
    index=$((RANDOM % ${#noms[@]}))
    dossier="${noms[$index]}"
    chemin="$chemin/$dossier"
  done

  mkdir -p ".$chemin"
  echo "echo 'Cette clé ne fonctionne pas.'" > ".$chemin/cle.sh"
  chmod +x ".$chemin/cle.sh"
done

# Choisir une clé valide parmi les chemins créés
cle_valide=$(find . -type f -name cle.sh | shuf -n 1)
echo "echo 'Bravo !'" > "$cle_valide"
chmod +x "$cle_valide"

# Créer l’indice (chemin relatif)
dossier_valide=$(dirname "$cle_valide")
echo "La bonne clé est dans le dossier : $dossier_valide" > indice.txt

# Enregistrer le chemin absolu comme réponse attendue
chemin_absolu=$(cd "$dossier_valide" && pwd)
echo "$chemin_absolu" > .bonne_reponse

# Message immersif
echo
echo " Le module est lancé."
echo "Lis le fichier indice.txt pour découvrir le dossier où se cache la bonne clé."
echo "Mais attention… seul son chemin absolu ajouté à la variable PATH te permettra de l’utiliser."
echo "Quand tu es prêt·e, lance cle.sh depuis n’importe où, puis ./verification_cles.sh pour valider."