#!/bin/bash

# Nettoyage du module Clés (toutes couches)
find . -type f -name cle.sh -exec rm -f {} \;
find . -type d -name "dossier_*" -exec rm -rf {} \;
rm -f indice.txt .bonne_reponse .erreurs_cles erreurs_cles.txt

echo "Module Clés réinitialisé."