#!/bin/bash

# Créer le dossier poches et y entrer
mkdir -p poches
cd poches || exit 1

# Générer les objets avec doublons
touch 1_cle.txt 2_cle.txt 3_verre.txt 4_verre.txt 5_ticket.txt 6_ticket.txt

echo "Tes poches sont pleines... fais le tri !"
echo "Indice : garde seulement les objets uniques avec le plus petit numéro."

