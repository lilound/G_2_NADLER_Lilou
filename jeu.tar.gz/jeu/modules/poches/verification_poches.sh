#!/bin/bash

error_file="../../.error"
[ ! -f "$error_file" ] && echo 0 > "$error_file"

increment_error() {
  current_errors=$(cat "$error_file")
  echo $((current_errors + 1)) > "$error_file"
}

cd poches || exit 1

# Vérifier que seuls les bons fichiers restent
if [[ -f 1_cle.txt && ! -f 2_cle.txt ]] &&
   [[ -f 3_verre.txt && ! -f 4_verre.txt ]] &&
   [[ -f 5_ticket.txt && ! -f 6_ticket.txt ]]; then
  echo "Bravo ! Tes poches sont allégées, tu peux entrer dans la soirée."
  echo "Module désamorcé" > ../../.module_OK
else
  echo "Dommage ! Tu as gardé trop d’objets ou supprimé les mauvais."
  increment_error
fi