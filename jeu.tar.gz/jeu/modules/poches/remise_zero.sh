#!/bin/bash
rm -rf poches
echo "Module Poches réinitialisé."